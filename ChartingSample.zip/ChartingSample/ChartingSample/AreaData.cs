﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChartingSample
{
    class AreaData
    {    
        public DateTime Date { get; set; }
        public double Price { get; set; }
        public int Volume { get; set; }
    }
}
